#pragma once

#include <iostream>

using namespace std;


struct Empleado
{
	string name;
	int years;
	int *pieces;
};

class Empresa
{
public:
	Empresa();
	int defineWorkers();
	void addWorker();
	void show();
private:
	void Ordenar();
	Empleado* workers;
	int space;
	int now = 0;
	int ordenado = 0;
};

