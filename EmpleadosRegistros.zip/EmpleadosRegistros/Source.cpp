#include "Empresa.h"


int main()
{
	Empresa Empresa;

	bool run = true;
	int definido = 0;

	while (run)
	{
		int opt;

		cout << endl << endl << "Men�";
		definido == 0 ? cout << endl << "1) Definir trabajadores" : cout << endl << "  Trabajadores definidos";
		cout << endl << "2) A�adir trabajador";
		cout << endl << "3) Mostrar trabajadores";
		cout << endl << "4) Salir";
		cout << endl << endl << "Ingresa la opci�n deseada: ";
		cin >> opt;

		switch (opt)
		{
		case 1:
			if (definido == 1)
			{
				cout << endl << "El n�mero de trabajadores ya est� definido" << endl;
			}
			else
			{
				definido = Empresa.defineWorkers();
			}
			break;
		case 2:
			Empresa.addWorker();
			break;
		case 3:
			Empresa.show();
			break;
		case 4:
			run = false;
			break;
		default:
			break;
		}
	}


}