#include "Empresa.h"

Empresa::Empresa()
{
}

int Empresa::defineWorkers()
{
	cout << "Ingresa la cantidad de empleados a registrar: ";
	cin >> space;

	workers = new Empleado[space];
	return 1;
}

void Empresa::addWorker()
{
	if (now == space)
	{
		cout << endl << endl << "Ya no hay espacio para a�adir nuevos trabajadores";
		return;
	}
	Empleado temp;
	string nombre;
	int anios;

	temp.pieces = new int[3];

	cout << endl << endl << "Ingresa el nombre del trabajador: ";
	cin >> nombre;

	cout << endl << endl << "Ingresa los a�os de antiguedad del empleado: ";
	cin >> anios;

	for (int i = 0; i < 3; i++)
	{
		int value = 0;
		cout << endl << "Ingresa el numero de piezas fabricadas en el mes " << i + 1 << ": ";
		cin >> value;
		*(temp.pieces) = value;
		cout << *temp.pieces;
		temp.pieces++;
	}

	for (int i = 0; i < 3; i++)
	{
		temp.pieces--;
	}

	temp.name = nombre;
	temp.years = anios;

	*workers = temp;

	cout << workers->name;

	workers++;
	now++;
	ordenado = 0;
}

void Empresa::show()
{

	if (ordenado == 0)
	{
		Ordenar();
	}

	for (int i = 0; i < now; i++)
	{
		workers--;
	}

	cout << "\n\nLos empleados registrados hasta el momento son\n\n";
	for (int i = 0; i < now; i++)
	{
		cout << "\n\nEmpleado " << i + 1 << "\n\n";
		cout << "Nombre: " << "\t" << workers->name << "\n";
		cout << "Antiguedad: " << "\t" << workers->years << "\n";
		
		for (int j = 0; j < 3; j++)
		{
			cout << endl << "Producci�n del mes " << j + 1 << ": " << *workers->pieces;
			workers->pieces++;
		}
		for (int i = 0; i < 3; i++)
		{
			workers->pieces--;
		}
		workers++;
	}


}

void Empresa::Ordenar()
{
	Empleado back;

	for (int i = 0; i < now; i++)
	{
		workers--;
	}

	for (int i = 0; i < now; i++)
	{
		if (i == now - 1)
		{
			break;
		}

		else if (workers->years > (workers + 1) ->years)
		{
			back = *(workers + 1);
			*(workers + 1) = *workers;
			*workers = back;
			Ordenar();
		}


	}

	workers += space;
	ordenado = 1;


}