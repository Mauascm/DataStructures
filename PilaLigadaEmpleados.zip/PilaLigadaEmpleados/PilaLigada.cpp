#include "PilaLigada.h"

PilaLigada::PilaLigada()
{
	setlocale(LC_ALL, "");
	tope = NULL;
}

void PilaLigada::Insertar(int clav, string name, int sueld)
{
	nodo = new Nodo;
	nodo->cve = clav;
	nodo->nom = name;
	nodo->sdo = sueld;
	nodo->anterior = tope;
	tope = nodo;
}

Nodo PilaLigada::Extraer()
{
	Nodo vacio;
	vacio.cve = -1;
	Nodo resultado;
	if (tope == NULL)
		return vacio;
	extraido = tope;
	tope = extraido->anterior;
	resultado = *extraido;
	delete extraido;
	return resultado;
}

Nodo PilaLigada::Consultar()
{
	Nodo vacio;
	vacio.cve = -1;
	if (tope == NULL)
		return vacio;
	return *tope;
}
void PilaLigada::Mostrar()
{
	cout << "\nPILA:" << endl;
	if (tope == NULL)
	{
		cout << "\n\tPila Vac�a" << endl;
		return;
	}
	nodo = tope;
	while (nodo != NULL)
	{
		cout << "\t" << nodo->nom << "\t" << nodo->anterior;
		if (nodo == tope) cout << "\t<-- Tope";
		cout << endl;

		nodo = nodo->anterior;
	}
	cout << endl;
}
