#pragma once
#include <iostream>

using namespace std;




struct Nodo
{
	int cve;
	string nom;
	int sdo;
	Nodo* anterior;
};

class PilaLigada
{
public:
	PilaLigada();
	void Insertar(int, string, int);
	Nodo Extraer();
	Nodo Consultar();
	void Mostrar();
private:
	Nodo* tope, * nodo, * extraido;
};

