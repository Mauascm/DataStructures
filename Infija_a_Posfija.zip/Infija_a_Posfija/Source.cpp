#include "cInfija.h";

int main()
{
	cInfija a;
	string op;
	string res;
	cout << "Ingresa la operaci�n: ";
	cin >> op;
	res = a.Work(op);
	cout << endl << endl << res;

}