#pragma once
#include <iostream>

using namespace std;

struct Nodo
{
	char val;
	Nodo* anterior;
};

class cInfija
{
public:
	cInfija();
	~cInfija();
	string Work(string);
private:
	void Push(char);
	char Pop();
	void Check(char);
	int Index(char);
	void Mostrar();
	Nodo* tope, *nodo, *extraido;
	string resultado;
	int max;
	string jerar[5] = {"(", "+-", "*/", "^", ")" };
};

