#include "cInfija.h"

cInfija::cInfija()
{
	setlocale(LC_ALL, "");
	tope = NULL;
	max = 0;
}

cInfija::~cInfija()
{}

void cInfija::Push(char nuevo)
{
	nodo = new Nodo;
	nodo->val = nuevo;
	nodo->anterior = tope;
	tope = nodo;
	max++;
}

char cInfija::Pop()
{
	int resultado;
	if (tope == NULL)
		return 'v';
	extraido = tope;
	tope = extraido->anterior;
	resultado = extraido->val;
	delete extraido;
	max--;
	return resultado;
}


int cInfija::Index(char b)
{
	int index;
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j <= jerar[i].size(); j++)
		{
			if (b == jerar[i][j])
			{
				index = i;
			}
		}
	}
	return index;
}

void cInfija::Mostrar()
{
	cout << "\nPILA:" << endl;
	if (tope == NULL)
	{
		cout << "\n\tPila Vac�a" << endl;
		return;
	}
	nodo = tope;
	while (nodo != NULL)
	{
		cout << "\t" << nodo->val << "\t" << nodo->anterior;
		if (nodo == tope) cout << "\t<-- Tope";
		cout << endl;

		nodo = nodo->anterior;
	}
	cout << endl;
}

void cInfija::Check(char a)
{
	int index;
	int index2;
	if (tope == NULL)
	{
		Push(a);
	}
	else
	{
		index = Index(a);
		index2 = Index(tope->val);

		cout << endl << "index de " << a << ": " << index;
		cout << endl << "index de " << tope->val << ": " << index2;

		if (index == 4)
		{
			for (int i = max; i >= 0; i--)
			{
				int ant = Index(tope->val);
				if (ant > 0)
				{
					resultado += Pop();
				}
				else if (ant == 0)
				{
					Pop();
					break;
				}
			}
			return;
		}


		if (index > index2 || index == 0)
		{
			Push(a);
		}
		else if (index <= index2)
		{
			for (int i = max; i > 0; i--)
			{
				int ant = Index(tope->val);

				if (index == ant)
				{
					resultado += tope->val;
					Pop();
					Push(a);
					break;
				}
				else if (index < ant)
				{
					if (ant == 0)
					{
						break;
					}
					else if (ant != 4)
					{
						resultado += Pop();
					}
						
				}
				else
				{
					Push(a);
					break; 
				}
			}
		}


	}
		
}

string cInfija::Work(string input)
{
	for (int i = 0; i < input.size(); i++)
	{
		cout << "Procesando: " << input[i];
		if (isdigit(input[i]) || isalpha(input[i]))
		{
			resultado += input[i];
		}
		else
		{
			Check(input[i]);
		}
		cout << endl << endl << "resultado: " << resultado;
		Mostrar();
	}

	if (tope != NULL)
	{
		for (int i = 0; i = max; i--)
		{
			resultado += Pop();
		}
	}

	return resultado;
}



