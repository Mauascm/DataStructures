#pragma once
#include <iostream>
#include <string>
using namespace std;


class ArregloBidim
{
public:
	ArregloBidim();
	void Mostrar();
	void Nombre();
	void Ordenar();
	//void Poblar();
private:
	int** val;
	int reng;
	int col;
	string nombre;
};

