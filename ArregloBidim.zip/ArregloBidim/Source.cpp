#include "ArregloBidim.h"

int main()
{
	setlocale(LC_ALL, "");
	ArregloBidim nums;
	int opc;

	do
	{
		cout << "\n1 Nombre 2 Poblar 3 Mostrar 4 Ordenar 5 Salir: ";
		cin >> opc;
		switch (opc)
		{
		case 1:
			nums.Nombre();
			break;
		case 2:
			//nums.Poblar();
			break;
		case 3:
			nums.Mostrar();
			break;
		case 4:
			nums.Ordenar();
			break;
		default:
			break;
		}
	} while (opc < 5);
}