#include "ArregloBidim.h"

ArregloBidim::ArregloBidim()
{
	setlocale(LC_ALL,"");
	cout << "Cu�ntos rengones?";
	cin >> reng;
	cout << "Cu�ntas Columnas?";
	cin >> col;

	val = new int* [reng];
	for (int i = 0; i < reng; i++)
	{
		*(val + i) = new int[col];
	}
}

void ArregloBidim::Mostrar()
{
	cout << "\n" << nombre << " tu ARREGLO es: " << endl;
	for (int i = 0; i < reng; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << "\t" << *(*(val + i) + j);
		}
		cout << endl;
	}
}

void ArregloBidim::Nombre()
{
	cout << "\nDime tu nombre: ";
	cin.ignore();
	getline(cin, nombre);
}

void ArregloBidim::Ordenar()
{
	cout << "\n\t\t ... ordenando ..." << endl << endl;
	bool ordenado;
	int it;
	int aux;

	for (int i = 0; i < reng; i++)
	{
		ordenado = false;
		it = 0;
		while (!ordenado)
		{
			ordenado = true;
			for (int j = 0; j < col - 1 - it; j++)
			{
				if (*(*(val + i) + j) > *(*(val + i) + j + 1))
				{
					aux = *(*(val + i) + j);
					*(*(val + i) + j) = *(*(val + i) + j + 1);
					*(*(val + i) + j + 1) = aux;
					ordenado = false;
				}
			}
			it++;
		}
	}
}